from decimal import Decimal
from pprint import pprint

import polars as pl

from finanzmaschine_core.catalog import asset_registry
from finanzmaschine_core.config import DATA_DIR_PATH
from finanzmaschine_core.portfolio.assets import CryptoEtp
from finanzmaschine_core.portfolio.operations import TradeEnum
from finanzmaschine_core.portfolio.operations.operation import Operation, parse_operation
from finanzmaschine_core.portfolio.positions import CryptoEtpPosition
from finanzmaschine_core.portfolio.records import CryptoEtpBrokerTradeRecord

df_ton_etp_flow = pl.read_csv(
    DATA_DIR_PATH / "private/etps/ton_etp_flow.csv",
    try_parse_dates=True,
    schema_overrides={
        "price": pl.String,
        "fee": pl.String,
        "base_asset_flow": pl.String,
        "quote_asset_flow": pl.String,
    },
).sort("datetime")


df_ton_etp_broker_trade_metadata = pl.read_csv(
    DATA_DIR_PATH / "private/etps/ton_etp_broker_trade_metadata.csv",
)

base_asset: CryptoEtp = asset_registry.get("CH1297762812")
position = CryptoEtpPosition(base_asset=base_asset)
closing_orders = ["FIFO", "FIFO"]
closing_order_index = 0
position.set_closing_order(closing_orders[closing_order_index])

for row in df_ton_etp_flow.iter_rows(named=True):
    operation_group_id = row["operation_group_id"]
    datetime = row["datetime"]
    operation: Operation = parse_operation(row["operation_type"], row["operation_variant"])
    base_asset_flow = row["base_asset_flow"]
    quantity = abs(Decimal(base_asset_flow))
    entitlement = Decimal(row["entitlement"]) if row["entitlement"] else None

    quote_asset = asset_registry.get(row["quote_asset_id"])
    price = Decimal(row["price"])
    price_source = row["price_source"]
    fee = Decimal(row["fee"])

    metadata_row = df_ton_etp_broker_trade_metadata.filter(
        pl.col("operation_group_id") == operation_group_id
    ).row(0, named=True)

    broker = metadata_row["broker"]
    account_id = metadata_row["account_id"]
    order_id = metadata_row["order_id"]
    exchange = metadata_row["exchange"]
    trade_id = metadata_row["trade_id"]

    record = CryptoEtpBrokerTradeRecord(
        quantity=quantity,
        datetime=datetime,
        operation=operation,
        quote_asset=quote_asset,
        price=price,
        price_source=price_source,
        fee=fee,
        broker=broker,
        account_id=account_id,
        order_id=order_id,
        exchange=exchange,
        trade_id=trade_id,
        entitlement=entitlement,
    )
    position.apply(record)

    if operation.variant == TradeEnum.SELL and closing_order_index < len(closing_orders) - 1:
        closing_order_index += 1
        position.set_closing_order(closing_orders[closing_order_index])

    # print("Quantity open:", position.quantity_open)
    # print("Quantity closed:", position.quantity_closed)

for lot in position.lots:
    print("Proceeds sold:", lot.proceeds_sold)
    print("Cost basis sold:", lot.cost_basis_sold)
    print("PnL sold:", lot.pnl_sold)
    for record_sold in lot.records_sold:
        pprint(record_sold)

print("Quantity closed:", position.quantity_closed)
print("Quantity open:", position.quantity_open)
print("Proceeds sold:", position.proceeds_sold)
print("Cost basis sold:", position.cost_basis_sold)
print("PnL sold:", position.pnl_sold)
